import fnToString from "./fnToString.js";

export default fnToString.call( Object );
