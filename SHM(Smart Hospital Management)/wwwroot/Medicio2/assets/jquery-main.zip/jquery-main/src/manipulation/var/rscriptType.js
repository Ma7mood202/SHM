export default ( /^$|^module$|\/(?:java|ecma)script/i );
